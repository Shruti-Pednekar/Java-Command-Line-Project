package project.com;
import java.time.LocalDate;

public class Student {
    private int id;
    private String name;
    private String email;
    private LocalDate dateOfAdmission;

    public Student(int id, String name, String email, LocalDate dateOfAdmission) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.dateOfAdmission = dateOfAdmission;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getDateOfJoining() {
        return dateOfAdmission;
    }

    @Override
    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", email=" + email + ", dateOfAdmission=" + dateOfAdmission + "]";
    }
}
