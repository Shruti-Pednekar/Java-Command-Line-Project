package project.com;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class StudentEnrollmentSystem {
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        boolean running = true;
        while (running) {
            showMenu();
            int choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    addCourse();
                    break;
                case 3:
                    addProfessor();
                    break;
                case 4:
                    enrollStudent();
                    break;
                case 5:
                    showEnrollments();
                    break;
                case 6:
                	 updateStudent();
                	 break;
                case 7:
                	viewStudents();
                	break;
                case 8:
                	deleteStudent();
                	break;
                case 9:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        sc.close();
    }

    private static void showMenu() 
    {	
    	System.out.println(" ");
    	System.out.println("**-------- STUDENT ENROLLEMENT SYSTEM ---------**");
    	System.out.println("");
        System.out.println("1. Add Student information:");
        System.out.println("2. Add Course information:  ");
        System.out.println("3. Add Professor information :");
        System.out.println("4. Enroll Student ");
        System.out.println("5. Show Enrollments of student: ");
        System.out.println("6. Update student information:  ");
        System.out.println("7. View student information:");
         System.out.println("8. Delete student record: ");
        System.out.println("9. Exit");
        System.out.println(" ");
        System.out.print("Enter your choice: ");
    }

    private static void addStudent() {
        System.out.print("Enter student id: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter student name: ");
        String name = sc.nextLine();
        System.out.print("Enter student email: ");
        String email = sc.nextLine();
        System.out.print("Enter date of admission (YYYY-MM-DD): ");
        LocalDate dateOfAdmission = LocalDate.parse(sc.nextLine());

        String sql = "INSERT INTO students (id, name, email, date_of_admission) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, email);
            ps.setDate(4, java.sql.Date.valueOf(dateOfAdmission));
            ps.executeUpdate();
            System.out.println("Student added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private static void addCourse() {
        System.out.print("Enter course id: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter course name: ");
        String name = sc.nextLine();
        System.out.print("Enter course description: ");
        String description = sc.nextLine();

        String sql = "INSERT INTO courses (id, name, description) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, description);
            ps.executeUpdate();
            System.out.println("Course added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addProfessor() {
        System.out.print("Enter professor id: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.print("Enter professor name: ");
        String name = sc.nextLine();
        System.out.print("Enter professor department: ");
        String department = sc.nextLine();

        String sql = "INSERT INTO professors (id, name, department) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, department);
            ps.executeUpdate();
            System.out.println("Professor added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void enrollStudent() {
        System.out.print("Enter student id: ");
        int studentId = Integer.parseInt(sc.nextLine());
        System.out.print("Enter course id: ");
        int courseId = Integer.parseInt(sc.nextLine());
        System.out.print("Enter professor id: ");
        int professorId = Integer.parseInt(sc.nextLine());

        String sql = "INSERT INTO enrollments (student_id, course_id, professor_id) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ps.setInt(3, professorId);
            ps.executeUpdate();
            System.out.println("Student enrolled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void showEnrollments() {
        String sql = "SELECT e.student_id, s.name as student_name, s.email, s.date_Of_Admission, e.course_id, c.name as course_name, e.professor_id, p.name as professor_name FROM enrollments e JOIN students s ON e.student_id = s.id JOIN courses c ON e.course_id = c.id JOIN professors p ON e.professor_id = p.id";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int studentId = rs.getInt("student_id");
                String studentName = rs.getString("student_name");
                String email = rs.getString("email");
                LocalDate dateOfAdmission = rs.getDate("date_of_Admission").toLocalDate();
                int courseId = rs.getInt("course_id");
                String courseName = rs.getString("course_name");
                int professorId = rs.getInt("professor_id");
                String professorName = rs.getString("professor_name");
                System.out.println("Enrollment [studentId=" + studentId + ", studentName=" + studentName + ", email=" + email + ", dateOfAdmission=" + dateOfAdmission + ", courseId=" + courseId + ", courseName=" + courseName + ", professorId=" + professorId + ", professorName=" + professorName + "]");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateStudent() {
        System.out.print("Enter student id to update: ");
        int id = Integer.parseInt(sc.nextLine());

        String checkSql = "SELECT * FROM students WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
            checkPs.setInt(1, id);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Student with id " + id + " not found.");
                    return;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("What would you like to update?");
        System.out.println("1. Name");
        System.out.println("2. Email");
        System.out.println("3. Date of admission");
        System.out.print("Enter your choice: ");
        int choice = Integer.parseInt(sc.nextLine());

        switch (choice) {
            case 1:
                System.out.print("Enter new student name: ");
                String newName = sc.nextLine();
                updateStudentAttribute(id, "name", newName);
                break;
            case 2:
                System.out.print("Enter new student email: ");
                String newEmail = sc.nextLine();
                updateStudentAttribute(id, "email", newEmail);
                break;
            case 3:
                System.out.print("Enter new date of admission (YYYY-MM-DD): ");
                String newDateOfAdmission = sc.nextLine();
                updateStudentAttribute(id, "date_of_admission", newDateOfAdmission);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void updateStudentAttribute(int id, String attribute, String newValue) {
        String sql = "UPDATE students SET " + attribute + " = ? WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if ("date_of_admission".equals(attribute)) {
                ps.setDate(1, java.sql.Date.valueOf(newValue));
            } else {
                ps.setString(1, newValue);
            }
            ps.setInt(2, id);
            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student " + attribute + " updated successfully.");
            } else {
                System.out.println("Failed to update student " + attribute + ".");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    private static void viewStudents() {
        String sql = "SELECT * FROM students";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                Date dateOfAdmission=rs.getDate("date_of_admission");
                System.out.println("Student [id =" + id + ", name =" + name + ", email =" + email + " ,  dateOfAdmission = "+ dateOfAdmission +"]");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    private static void deleteStudent() {
        System.out.println("Enter student id to delete: ");
        int id = Integer.parseInt(sc.nextLine());

        String checkSql = "SELECT * FROM students WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
            checkPs.setInt(1, id);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Student with id " + id + " not found.");
                    return;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rowsDeleted = ps.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student record deleted successfully.");
            } else {
                System.out.println("Failed to delete student record.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    }
    
  

