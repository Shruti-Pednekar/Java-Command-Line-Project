package project.com;

public class Enrollment {
    private int studentId;
    private int courseId;
    private int professorId;

    public Enrollment(int studentId, int courseId, int professorId) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.professorId = professorId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public int getProfessorId() {
        return professorId;
    }

    @Override
    public String toString() {
        return "Enrollment [studentId=" + studentId + ", courseId=" + courseId + ", professorId=" + professorId + "]";
    }
}

